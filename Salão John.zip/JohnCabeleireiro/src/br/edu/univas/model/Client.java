package br.edu.univas.model;

import java.util.Date;

public class Client {

	private String nome;
	private String telefone;
	private String email;
	private String address;
	private Date nascimento;
	public void setNascimento(Date nascimento) {
		this.nascimento = nascimento;
	}
	private String sexo;
	private String cpf;
	private String obsCab;
	
	public Date getNascimento() {
		return nascimento;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getObsCab() {
		return obsCab;
	}
	public void setObsCab(String obsCab) {
		this.obsCab = obsCab;
	}
	
	
	
		
}
