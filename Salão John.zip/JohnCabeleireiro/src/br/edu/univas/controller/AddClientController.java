package br.edu.univas.controller;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JTextField;

import br.edu.univas.dao.ClientDAO;
import br.edu.univas.listener.SaveButtonListener;
import br.edu.univas.model.Client;
import br.edu.univas.view.AddClientPanel;

public class AddClientController {

	private AddClientPanel addClientPanel;
	private ClientDAO dao;
	private Client client;
	
	public AddClientController() throws SQLException {
		dao = new ClientDAO();
		addClientPanel = new AddClientPanel();
		addClientPanel.setListener(new SaveButtonListener() {
			
			@Override
			public void save() {
				saveClient();
			}
		});
	}
	
	private void saveClient() {
		
		SimpleDateFormat ft =  new SimpleDateFormat("dd-MM-yyyy"); 
		Date nascimento =null;
		try {
			nascimento = ft.parse(addClientPanel.getNascimentoTextField().getText());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		java.sql.Date nascimentoFinal = new java.sql.Date (nascimento.getTime());
		
		client = new Client();
		client.setNome(addClientPanel.getNameTextField().getText());
		client.setCpf(addClientPanel.getCpfTextField().getText());
		client.setEmail(addClientPanel.getEmailTextField().getText());
		client.setAddress(addClientPanel.getAddressTextField().getText());
		client.setTelefone(addClientPanel.getPhoneTextField().getText());
		client.setNascimento(nascimentoFinal);
		client.setSexo(addClientPanel.getSexoTextField().getText());
		client.setObsCab(addClientPanel.getCabeloTextField().getText());
		
		dao.save(client);
		clearFields();
	}
	
	private void clearFields() {
		List<JTextField> fields = Arrays.asList(
				addClientPanel.getNameTextField(), 
				addClientPanel.getCpfTextField(),
				addClientPanel.getEmailTextField(),
				addClientPanel.getAddressTextField(),
				addClientPanel.getNascimentoTextField(),
				addClientPanel.getSexoTextField(),
				addClientPanel.getCabeloTextField(),
				addClientPanel.getPhoneTextField());
		
		for (JTextField jTextField : fields) {
			clearField(jTextField);
		}
	}
	
	private void clearField(JTextField textField) {
		textField.setText(null);
	}
	
	public JPanel getComponent() {
		return addClientPanel;
	}
	
}
