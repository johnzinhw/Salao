package br.edu.univas.controller;

import java.awt.Component;
import java.sql.SQLException;

import javax.swing.SwingUtilities;

import br.edu.univas.listener.TopButtonListener;
import br.edu.univas.view.MainView;
import br.edu.univas.view.TelaLogin;

public class MainController {

	private AddClientController addController;
	private ListClientController listController;
	private TelaLoginController loginController;
	private MainView mainView;
	
	public MainController() throws SQLException {
		mainView = new MainView();
		addController = new AddClientController();
		listController = new ListClientController();
		loginController = new TelaLoginController();
	}
	
	public void iniciarApp() {
		mainView.setListener(new TopButtonListener() {
			
			@Override
			public void showListView() {
				showListClientPanel();
			}
			
			@Override
			public void showAddView() {
				showAddClientPanel();
			}
		});
		mainView.setVisible(true);
		//showAddClientPanel();
//		TelaLogin tela = new TelaLogin();
//		showPanel(tela);
	}
	
	private void showAddClientPanel() {
		showPanel(addController.getComponent());
	}
	
	private void showListClientPanel() {
		showPanel(listController.getComponent());
	}
	
	
	private void showPanel(Component component) {
		mainView.getCenterPanel().removeAll();
		mainView.getCenterPanel().add(component);
		mainView.getCenterPanel().revalidate();
		SwingUtilities.updateComponentTreeUI(mainView);
	}
	
}
