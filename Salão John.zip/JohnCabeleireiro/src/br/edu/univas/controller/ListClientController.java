package br.edu.univas.controller;

import java.awt.Component;
import java.sql.SQLException;

import br.edu.univas.dao.ClientDAO;
import br.edu.univas.view.ListClientPanel;

public class ListClientController {

	private ListClientPanel panel;
	private ClientDAO dao;
	
	public ListClientController() throws SQLException {
		dao = new ClientDAO();
		panel = new ListClientPanel();
	}
	
	public Component getComponent() {
		panel.updateClients(dao.getAll());
		return panel;
	}
	
}
