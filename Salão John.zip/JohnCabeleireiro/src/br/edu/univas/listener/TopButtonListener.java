package br.edu.univas.listener;

public interface TopButtonListener {

	void showAddView();
	
	void showListView();
	
}
