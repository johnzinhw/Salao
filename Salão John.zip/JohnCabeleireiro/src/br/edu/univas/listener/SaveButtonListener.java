package br.edu.univas.listener;

public interface SaveButtonListener {

	void save();
	
}
