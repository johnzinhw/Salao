package br.edu.univas.view;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class TelaLogin extends JPanel {

	private JTextField userTextField;
	private JTextField passTextField;
	
	public TelaLogin() {
		addComponents();
	}
	
	private void addComponents() {
		this.setLayout(new GridBagLayout());
		
		GridBagConstraints gbc = new GridBagConstraints();
		
		JLabel userLabel = new JLabel();
		userLabel.setText("Usuario:");
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.LINE_START;
		this.add(userLabel, gbc);
		
		userTextField = new JTextField();
		gbc.gridx = 1;
		gbc.weightx = 1.0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		this.add(userTextField, gbc);
		
		JLabel passLabel = new JLabel();
		passLabel.setText("Senha:");
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 0.0;
		this.add(passLabel, gbc);
		
		passTextField = new JTextField();
		gbc.gridx = 1;
		gbc.weightx = 1.0;
		this.add(passTextField, gbc);
		
		JButton logButton = new JButton();
		logButton.setText("Entrar");
		logButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				
			}
		});
		gbc.gridx = 0;
		gbc.gridy = 8;
		gbc.gridwidth = 2;
		gbc.weightx = 0.0;
		gbc.anchor = GridBagConstraints.CENTER;
		gbc.fill = GridBagConstraints.NONE;
		this.add(logButton, gbc);
		
//		ImageIcon telaP = new ImageIcon(getClass().getResource("barbe.jpg"));
//		JLabel imgLabel = new JLabel(telaP);
//		//imgLabel.setPreferredSize(new Dimension(750,200));
//		this.add(imgLabel, gbc);
		
	}

}

