package br.edu.univas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import br.edu.univas.model.Client;

public class ClientDAO {

	private Connection connection;

	private static ArrayList<Client> data = new ArrayList<>();

	public ClientDAO() throws SQLException {
		connection = ConnectionUtil.getConnection();
	}

	public void save(Client client) {

		String sql = "insert into client (nome, email, cpf, telefone, address, nascimento, sexo, obscabelo)" 
		+ "values (?, ?, ?, ?, ?, ?, ?, ?)";

		int index = 1;
		try {
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(index++, client.getNome());
			statement.setString(index++, client.getEmail());
			statement.setString(index++, client.getCpf());
			statement.setString(index++, client.getTelefone());
			statement.setString(index++, client.getAddress());
			statement.setDate(index++, (Date) client.getNascimento());
			statement.setString(index++, client.getSexo());
			statement.setString(index++, client.getObsCab());

			statement.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public ArrayList<Client> getAll() {

		ArrayList<Client> data = new ArrayList<>();
		String sql = "select * from client";
		try {
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(sql);
			while (resultSet.next()) {
				Client client = new Client();
				client.setNome(resultSet.getString("nome"));
				client.setCpf(resultSet.getString("cpf"));
				client.setEmail(resultSet.getString("email"));
				client.setTelefone(resultSet.getString("telefone"));
				client.setAddress(resultSet.getString("address"));
				client.setNascimento(resultSet.getDate("nascimento"));
				client.setSexo(resultSet.getString("sexo"));
				client.setObsCab(resultSet.getString("obscabelo"));

				data.add(client);

			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return data;
	}

}
